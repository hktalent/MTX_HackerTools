<div class="cta padding-bottom">
	<h3>Resources</h3>
	<ul>
		<li><a target="blank" href="https://connekthq.com/plugins/ajax-load-more/">Ajax Load More Demo Site</a></li>
		<li><a target="blank" href="http://wordpress.org/plugins/ajax-load-more">Documentation</a></li>
		<li><a target="blank" href="http://wordpress.org/support/plugin/ajax-load-more">Plugin Support/Issues</a></li>
		<li><a target="blank" href="https://wordpress.org/support/view/plugin-reviews/ajax-load-more">Reviews</a></li>
	</ul>	
	<a href="https://github.com/dcooney/wordpress-ajax-load-more" target="blank" class="visit"><i class="fa fa-github"></i> Latest build on Github</a>
</div>			