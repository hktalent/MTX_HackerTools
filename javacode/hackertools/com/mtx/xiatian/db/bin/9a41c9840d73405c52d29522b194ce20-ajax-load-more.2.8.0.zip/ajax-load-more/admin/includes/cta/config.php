<div class="cta">
	<h3><?php _e('Plugin Configurations', ALM_NAME); ?></h3>
	<div class="item">
	   <h4><?php _e('Plugin Version', ALM_NAME); ?></h4>
	   <?php
	    echo '<p>'. ALM_VERSION .'</p>';
	 ?>
	</div>
	<div class="item">
	   <h4><?php _e('Release Date', ALM_NAME); ?></h4>
	   <?php
	    echo '<p>'. ALM_RELEASE .'</p>';
	 ?>
	</div>
</div>