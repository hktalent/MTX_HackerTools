<div class="alm-drop-btn alm-repeater-options">
   <a href="javascript:void(0);" class="target"><i class="fa fa-cog"></i> <?php _e('Options', ALM_NAME); ?></a>
	<div class="alm-dropdown">
	   <div class="alm-drop-inner">
   	   <ul>
   	      <li class="option-update"><a href="javascript:void(0);"><i class="fa fa-download"></i>  <?php _e('Update Template from Database', ALM_NAME); ?></a></li>
   	      <li class="copy"><a href="javascript:void(0);"><i class="fa fa-files-o"></i>  <?php _e('Copy Template Data', ALM_NAME); ?></a></li>
   	   </ul>
	   </div>
	</div>
</div>